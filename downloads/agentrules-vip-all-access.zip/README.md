# AgentRules.dev — VIP All-Access Bundle
Thank you for your purchase! You now have lifetime access to the entire curated library of battle-tested AI coding rulesets.

## Quickstart Guide

### 1. Cursor IDE
- Copy the desired `.cursorrules` file directly into your project's root directory:
  `cp rulesets/01-fullstack-nextjs-tailwind.cursorrules /path/to/project/.cursorrules`
- Restart or reload Cursor. Your AI will now automatically follow strict senior engineering patterns.

### 2. Antigravity & Windsurf
- Rename or merge the ruleset content into your `AGENTS.md` file in the project root or user home directory:
  `cat rulesets/03-autonomous-agent-odd-protocol.md >> /path/to/project/AGENTS.md`

### 3. Claude Code & Terminal Agents
- Copy the file into your project as `CLAUDE.md`:
  `cp rulesets/02-fastapi-python-clean-architecture.cursorrules /path/to/project/CLAUDE.md`

---
Support & Updates: Contact ceopatinhalo@gmail.com
Curated with care by TEMA AI & NextSkill.
