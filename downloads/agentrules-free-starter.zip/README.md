# AgentRules.dev — Free Starter Pack
Includes 4 battle-tested starter rulesets for Next.js, FastAPI, Docker, and AI SEO.

To unlock the full 50+ enterprise rulesets, autonomous agent protocols, and private skills vault, upgrade at https://agentrules.dev/

Curated with care by TEMA AI.
